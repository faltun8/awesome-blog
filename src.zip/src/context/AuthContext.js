import { createContext, useState, useEffect } from "react";

export const AuthContext = createContext();

function  AuthContextProvider(props) {
  const [token, setToken] = useState();


  useEffect(() => {
    const token =  localStorage.getItem("token");
    setToken(token)
        
    
  }, [token]);

  return (
    <AuthContext.Provider value={{ token }}>
      {props.children}
    </AuthContext.Provider>
  );
}

export default AuthContextProvider;
