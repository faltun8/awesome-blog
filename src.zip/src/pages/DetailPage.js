import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";

export default function DetailPage() {
  const { state } = useLocation();
  const mySlug = state.slug
  console.log(state.slug);

  const token = localStorage.getItem("token");

  useEffect(() => {
    console.log("test");
    if (token){
        getPostDetails(mySlug);
    }
  }, []);


  async function getPostDetails(slug) {
    
    await axios
      .get(
        `https://blog-backend-django.herokuapp.com/api/${slug}/`,
        {
          headers: { Authorization: `${token}` },
        },
        {
          key: "value",
        }
      )
      .then((res) => console.log(res));
  }


  return <div>detail page</div>;
}
