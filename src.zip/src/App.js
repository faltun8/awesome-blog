
import AppRouter from '../src/router/Router'

const App = () => {
  return (
   <AppRouter/>
  );
};
export default App;
